<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</head>
<body>
    <div class="container mt-4">
        <h1>Bienvenido, <?php echo session()->get('usuario'); ?></h1>

        <h2>Mis roles y módulos:</h2>
        <ul>
            <?php foreach ($rolesYModulos as $item): ?>
                <li><strong>Rol:</strong> <?php echo $item['nombre_rol']; ?> - <strong>Módulo:</strong> <?php echo $item['nombre_modulo']; ?></li>
            <?php endforeach; ?>
        </ul>

        <div class="row">
            <div class="col-12 col-md-4 mb-3">
                <h2>Usuarios:</h2>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Nombre</th>
                            <th>Correo electrónico</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($usuarios as $usuario): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($usuario['nombre']); ?></td>
                                <td><?php echo htmlspecialchars($usuario['correo']); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <div class="col-12 col-md-4 mb-3">
                <h2>Roles:</h2>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Rol</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($roles as $item): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($item['nombre_rol']); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <div class="col-12 col-md-4 mb-3">
                <h2>Módulos:</h2>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Módulo</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($modulos as $item): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($item['nombre_modulo']); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <a href="<?= base_url('/auth/cerrarSesion') ?>" class="btn btn-danger">Cerrar sesión</a>
    </div>
</body>
</html>

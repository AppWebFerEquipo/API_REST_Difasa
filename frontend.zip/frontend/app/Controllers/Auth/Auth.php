<?php

namespace App\Controllers\Auth;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\CURLRequest;
use CodeIgniter\API\ResponseTrait;

class Auth extends BaseController
{
    use ResponseTrait;

    public function index()
    {
        return view('auth/login');  
    }

    public function login()
    {
        $email = $this->request->getVar('email');
        $password = $this->request->getVar('password');

        $apiUrl = 'http://localhost/backend/public/login';  

        $data = [
            'email' => $email,
            'password' => $password
        ];

        $client = \Config\Services::curlrequest();
        try {
            $response = $client->request('POST', $apiUrl, [
                'form_params' => $data
            ]);
            
            $responseData = json_decode($response->getBody(), true);

            if ($responseData['status'] == 200) {
                $rolesYModulos = $responseData['data']['roles_y_modulos'];

                $usuarios = $client->request('GET', "http://localhost/backend/public/usuarios");

                $usuarios = json_decode($usuarios->getBody(), true);

                $usuarios = $usuarios['data'] ?? [];

                $roles = $client->request('GET', "http://localhost/backend/public/roles");

                $roles = json_decode($roles->getBody(), true);

                $roles = $roles['data'] ?? [];

                $modulos = $client->request('GET', "http://localhost/backend/public/modulos");

                $modulos = json_decode($modulos->getBody(), true);

                $modulos = $modulos['data'] ?? [];
                

                session()->set([
                    'usuario' => $email,  
                    'roles_y_modulos' => $rolesYModulos
                ]);

                return view('auth/dashboard', ['rolesYModulos' => $rolesYModulos, 'usuarios' => $usuarios, 'roles' => $roles, 'modulos' => $modulos]);
            } else {
                return view('auth/login', ['error' => 'Usuario o contraseña incorrectos.']);
            }

        } catch (\Exception $e) {
            return view('auth/login', ['error' => 'Hubo un problema con la conexión.']);
        }
    }

    public function cerrarSesion()
    {
        session()->destroy();

        return redirect()->to('/');
    }
}

<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Auth\Auth::index');
$routes->post('/auth/login', 'Auth\Auth::login');
$routes->get('/auth/cerrarSesion', 'Auth\Auth::cerrarSesion');

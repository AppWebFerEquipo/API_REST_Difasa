<?php

namespace App\Controllers\Usuarios;

use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use Psr\Log\LoggerInterface;
use App\Models\MUsuarios;
use App\Controllers\BaseController;

class CUsuarios extends BaseController
{
    protected $musuario;

    public function __construct()
    {
        $this->musuario = new MUsuarios();
    }

    public function index()
    {
        $usuarios = $this->musuario->obtenerUsuarios();

        if (empty($usuarios)) {
            return $this->response->setJSON([
                'status' => 404,
                'message' => 'No se encontraron usuarios',
                'data' => []
            ]);
        }

        return $this->response->setJSON([
            'status' => 200,
            'message' => 'Usuarios encontrados',
            'data' => $usuarios
        ]);
    }

    public function create()
    {
        $correo = $this->request->getPost('correo');
        $password = $this->request->getPost('password');
        $nombre = $this->request->getPost('nombre');
        $validation = \Config\Services::validation();

        $validation->setRules([
            'correo' => 'required|string',
            'correo' => 'required|string',
            'password' => 'required|min_length[8]',
            'nombre' => 'required|string'
        ]);

        if (!$validation->withRequest($this->request)->run()) {
            return $this->response->setJSON([
            'status' => 400,
            'message' => 'Validación fallida',
            'errors' => $validation->getErrors(),
            'data' => []
            ]);
        }

        if ($this->musuario->obtenerUsuarios(['correo' => $correo])) {
            return $this->response->setJSON([
                'status' => 400,
                'message' => 'El usuario ya existe',
                'data' => []
            ]);
        }

        $data = [
            'correo' => $correo,
            'password' => sha1($password),
            'nombre' => $nombre,
            'creado' => date('Y-m-d H:i:s')
        ];

        if ($this->musuario->crearUsuario($data)) {
            return $this->response->setJSON([
                'status' => 200,
                'message' => 'Usuario creado',
                'data' => []
            ]);
        } else {
            return $this->response->setJSON([
                'status' => 500,
                'message' => 'Error al crear usuario',
                'data' => []
            ]);
        }
        

    }

    public function update()
    {
        if ($this->request->getMethod() !== 'put') {
            return $this->response->setJSON([
                'status' => 405,
                'message' => 'Método no permitido, se requiere PUT',
                'data' => []
            ]);
        }

        $inputData = $this->request->getJSON();

        if (!$inputData || !isset($inputData->correo) || !isset($inputData->password) || !isset($inputData->nombre)) {
            return $this->response->setJSON([
                'status' => 400,
                'message' => 'Faltan datos requeridos',
                'data' => []
            ]);
        }

        $correo = $inputData->correo;
        $password = $inputData->password;
        $nombre = $inputData->nombre;

        $validation = \Config\Services::validation();
        $validation->setRules([
            'correo' => 'required|string',
            'password' => 'required|min_length[8]',
            'nombre' => 'required|string'
        ]);

        if (!$validation->run((array) $inputData)) {
            return $this->response->setJSON([
                'status' => 400,
                'message' => 'Validación fallida',
                'errors' => $validation->getErrors(),
                'data' => []
            ]);
        }

        if (!$this->musuario->obtenerUsuarios(['correo' => $correo])) {
            return $this->response->setJSON([
                'status' => 404,
                'message' => 'El usuario no existe',
                'data' => []
            ]);
        }

        $data = [
            'correo' => $correo,
            'password' => sha1($password),
            'nombre' => $nombre
        ];

        if ($this->musuario->actualizarUsuario($data, ['correo' => $correo])) {
            return $this->response->setJSON([
                'status' => 200,
                'message' => 'Usuario actualizado',
                'data' => []
            ]);
        } else {
            return $this->response->setJSON([
                'status' => 500,
                'message' => 'Error al actualizar usuario',
                'data' => []
            ]);
        }
    }
    
    public function delete()
{
    // Verifica si la solicitud es DELETE
    if ($this->request->getMethod() !== 'delete') {
        return $this->response->setJSON([
            'status' => 405,
            'message' => 'Método no permitido, se requiere DELETE',
            'data' => []
        ]);
    }

    // Obtener los datos de la solicitud DELETE en formato JSON
    $inputData = $this->request->getJSON();

    // Verificar que el correo esté presente
    if (!isset($inputData->correo)) {
        return $this->response->setJSON([
            'status' => 400,
            'message' => 'Falta el correo del usuario',
            'data' => []
        ]);
    }

    $correo = $inputData->correo;

    // Validación
    $validation = \Config\Services::validation();
    $validation->setRules([
        'correo' => 'required|string'
    ]);

    if (!$validation->run((array) $inputData)) {
        return $this->response->setJSON([
            'status' => 400,
            'message' => 'Validación fallida',
            'errors' => $validation->getErrors(),
            'data' => []
        ]);
    }

    // Verificar si el usuario existe
    if (!$this->musuario->obtenerUsuarios(['correo' => $correo])) {
        return $this->response->setJSON([
            'status' => 404,
            'message' => 'El usuario no existe',
            'data' => []
        ]);
    }

    // Eliminar el usuario
    if ($this->musuario->eliminarUsuario(['correo' => $correo])) {
        return $this->response->setJSON([
            'status' => 200,
            'message' => 'Usuario eliminado',
            'data' => []
        ]);
    } else {
        return $this->response->setJSON([
            'status' => 500,
            'message' => 'Error al eliminar usuario',
            'data' => []
        ]);
    }
}

}
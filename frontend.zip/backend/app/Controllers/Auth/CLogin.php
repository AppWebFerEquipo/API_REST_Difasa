<?php
namespace App\Controllers\Auth;

use App\Controllers\BaseController;
use App\Models\MUsuarios;
use CodeIgniter\API\ResponseTrait;
use Firebase\JWT\JWT;

class CLogin extends BaseController
{
    use ResponseTrait;
    protected $musuario;

    public function __construct()
    {
        $this->musuario = new MUsuarios();
    }

    public function index()
    {
        $rules = [
            'email' => 'required|valid_email',
            'password' => 'required|min_length[6]'
        ];

        if (!$this->validate($rules)) {
            return $this->fail($this->validator->getErrors());
        }

        $email = $this->request->getVar('email');
        $password = $this->request->getVar('password');

        // Obtener el usuario autenticado
        $usuarios = $this->musuario->obtenerUsuarios(['correo' => $email, 'password' => sha1($password)]);
        
        if (empty($usuarios)) {
            return $this->response->setJSON([
                'status' => 404,
                'message' => 'Usuario no encontrado ' . $email,
                'data' => []
            ]);
        }


        // Obtener roles y módulos del usuario
        $rolesYModulos = $this->musuario->obtenerRolesYModulos($usuarios[0]['id_usuario']);

        return $this->response->setJSON([
            'status' => 200,
            'message' => 'Usuario encontrado',
            'data' => [
                'roles_y_modulos' => $rolesYModulos  // Incluir solo los roles y módulos en la respuesta
            ]
        ]);
    }
}

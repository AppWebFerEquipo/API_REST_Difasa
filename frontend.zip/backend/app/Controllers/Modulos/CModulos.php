<?php

namespace App\Controllers\Modulos;

use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use Psr\Log\LoggerInterface;
use App\Models\MModulos;
use App\Controllers\BaseController;

class CModulos extends BaseController
{
    protected $mmodulos;

    public function __construct()
    {
        $this->mmodulos = new MModulos();
    }

    public function index()
    {
        $modulos = $this->mmodulos->obtenerModulos();

        if (empty($modulos)) {
            return $this->response->setJSON([
                'status' => 404,
                'message' => 'No se encontraron modulos',
                'data' => []
            ]);
        }

        return $this->response->setJSON([
            'status' => 200,
            'message' => 'Modulos encontrados',
            'data' => $modulos
        ]);
    }

    public function create()
    {
        $nombre = $this->request->getPost('nombre');
        $validation = \Config\Services::validation();

        $validation->setRules([
            'nombre' => 'required|string',
        ]);

        if (!$validation->withRequest($this->request)->run()) {
            return $this->response->setJSON([
            'status' => 400,
            'message' => 'Validación fallida',
            'errors' => $validation->getErrors(),
            'data' => []
            ]);
        }

        $data = [
            'nombre_modulo' => $nombre,
        ];

        if ($this->mmodulos->crearModulo($data)) {
            return $this->response->setJSON([
                'status' => 200,
                'message' => 'Modulo creado correctamente',
                'data' => []
            ]);
        }

        return $this->response->setJSON([
            'status' => 500,
            'message' => 'No se pudo crear el modulo',
            'data' => []
        ]);
    }

    public function update()
    {
    // Verifica si la solicitud es PUT
    if ($this->request->getMethod() !== 'put') {
        return $this->response->setJSON([
            'status' => 405,
            'message' => 'Método no permitido, se requiere PUT',
            'data' => []
        ]);
    }

    // Obtener los datos de la solicitud PUT en formato JSON
    $inputData = $this->request->getJSON();

    // Verificar que el id y nombre estén presentes
    if (!isset($inputData->id) || !isset($inputData->nombre)) {
        return $this->response->setJSON([
            'status' => 400,
            'message' => 'Faltan datos requeridos',
            'data' => []
        ]);
    }

    $id = $inputData->id;
    $nombre = $inputData->nombre;

    // Validación
    $validation = \Config\Services::validation();
    $validation->setRules([
        'id' => 'required|numeric',
        'nombre' => 'required|string',
    ]);

    if (!$validation->run((array) $inputData)) {
        return $this->response->setJSON([
            'status' => 400,
            'message' => 'Validación fallida',
            'errors' => $validation->getErrors(),
            'data' => []
        ]);
    }

    // Datos para actualizar
    $data = [
        'nombre_modulo' => $nombre,
    ];

    // Condición para actualizar
    $where = [
        'id_modulo' => $id
    ];

    // Actualizar el módulo
    if ($this->mmodulos->actualizarModulo($data, $where)) {
        return $this->response->setJSON([
            'status' => 200,
            'message' => 'Módulo actualizado correctamente',
            'data' => []
        ]);
    }

    return $this->response->setJSON([
        'status' => 500,
        'message' => 'No se pudo actualizar el módulo',
        'data' => []
    ]);
}


public function delete()
{
    // Verifica si la solicitud es DELETE
    if ($this->request->getMethod() !== 'delete') {
        return $this->response->setJSON([
            'status' => 405,
            'message' => 'Método no permitido, se requiere DELETE',
            'data' => []
        ]);
    }

    // Obtener los datos de la solicitud DELETE en formato JSON
    $inputData = $this->request->getJSON();

    // Verificar que el id esté presente
    if (!isset($inputData->id)) {
        return $this->response->setJSON([
            'status' => 400,
            'message' => 'Falta el id del módulo',
            'data' => []
        ]);
    }

    $id = $inputData->id;

    // Validación
    $validation = \Config\Services::validation();
    $validation->setRules([
        'id' => 'required|numeric',
    ]);

    if (!$validation->run((array) $inputData)) {
        return $this->response->setJSON([
            'status' => 400,
            'message' => 'Validación fallida',
            'errors' => $validation->getErrors(),
            'data' => []
        ]);
    }

    // Condición para eliminar
    $where = [
        'id_modulo' => $id
    ];

    // Eliminar el módulo
    if ($this->mmodulos->eliminarModulo($where)) {
        return $this->response->setJSON([
            'status' => 200,
            'message' => 'Módulo eliminado correctamente',
            'data' => []
        ]);
    }

    return $this->response->setJSON([
        'status' => 500,
        'message' => 'No se pudo eliminar el módulo',
        'data' => []
    ]);
}

}
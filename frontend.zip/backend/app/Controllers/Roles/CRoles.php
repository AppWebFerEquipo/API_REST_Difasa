<?php

namespace App\Controllers\Roles;

use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use Psr\Log\LoggerInterface;
use App\Models\MRoles;
use App\Controllers\BaseController;

class CRoles extends BaseController
{
    protected $mroles;

    public function __construct()
    {
        $this->mroles = new MRoles();
    }

    public function index()
    {
        $roles = $this->mroles->obtenerRoles();

        if (empty($roles)) {
            return $this->response->setJSON([
                'status' => 404,
                'message' => 'No se encontraron roles',
                'data' => []
            ]);
        }

        return $this->response->setJSON([
            'status' => 200,
            'message' => 'Roles encontrados',
            'data' => $roles
        ]);
    }

    public function create()
    {
        $nombre = $this->request->getPost('nombre');
        $validation = \Config\Services::validation();

        $validation->setRules([
            'nombre' => 'required|string',
        ]);

        if (!$validation->withRequest($this->request)->run()) {
            return $this->response->setJSON([
            'status' => 400,
            'message' => 'Validación fallida',
            'errors' => $validation->getErrors(),
            'data' => []
            ]);
        }

        $data = [
            'nombre_rol' => $nombre,
        ];

        $this->mroles->crearRol($data);

        return $this->response->setJSON([
            'status' => 200,
            'message' => 'Rol creado',
            'data' => []
        ]);
    }

    public function update()
    {
        if ($this->request->getMethod() !== 'put') {
            return $this->response->setJSON([
                'status' => 405,
                'message' => 'Método no permitido, se requiere PUT',
                'data' => []
            ]);
        }
    
        $inputData = $this->request->getJSON();
    
        if (!isset($inputData->id) || !isset($inputData->nombre)) {
            return $this->response->setJSON([
                'status' => 400,
                'message' => 'Faltan datos requeridos',
                'data' => []
            ]);
        }
    
        $id = $inputData->id;
        $nombre = $inputData->nombre;
    
        $validation = \Config\Services::validation();
        $validation->setRules([
            'id' => 'required|numeric',
            'nombre' => 'required|string',
        ]);
    
        if (!$validation->run((array) $inputData)) {
            return $this->response->setJSON([
                'status' => 400,
                'message' => 'Validación fallida',
                'errors' => $validation->getErrors(),
                'data' => []
            ]);
        }
    
        $data = [
            'nombre_rol' => $nombre,
        ];
    
        $this->mroles->actualizarRol($data, ['id_rol' => $id]);
    
        return $this->response->setJSON([
            'status' => 200,
            'message' => 'Rol actualizado',
            'data' => []
        ]);
    }
    
    public function delete()
    {
        // Verifica si la solicitud es DELETE
        if ($this->request->getMethod() !== 'delete') {
            return $this->response->setJSON([
                'status' => 405,
                'message' => 'Método no permitido, se requiere DELETE',
                'data' => []
            ]);
        }
    
        // Obtener los datos de la solicitud DELETE en formato JSON
        $inputData = $this->request->getJSON();
    
        // Verificar que el id esté presente
        if (!isset($inputData->id)) {
            return $this->response->setJSON([
                'status' => 400,
                'message' => 'Falta el id del rol',
                'data' => []
            ]);
        }
    
        $id = $inputData->id;
    
        // Validación
        $validation = \Config\Services::validation();
        $validation->setRules([
            'id' => 'required|numeric'
        ]);
    
        if (!$validation->run((array) $inputData)) {
            return $this->response->setJSON([
                'status' => 400,
                'message' => 'Validación fallida',
                'errors' => $validation->getErrors(),
                'data' => []
            ]);
        }
    
        // Eliminar el rol
        $this->mroles->eliminarRol(['id_rol' => $id]);
    
        return $this->response->setJSON([
            'status' => 200,
            'message' => 'Rol eliminado',
            'data' => []
        ]);
    }
    

}
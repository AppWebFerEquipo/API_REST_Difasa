<?php

namespace App\Models;

use CodeIgniter\Model;


class MUsuarios extends Model
{
    protected $table;
    protected $db;

    public function __construct()
    {
        parent::__construct();
        $this->table = 'usuarios';
        $this->db = \Config\Database::connect();

    }

    public function obtenerUsuarios($where = null)
    {
        if ($where) {
            return $this->db->table($this->table)->where($where)->get()->getResultArray();
        }
        return $this->db->table($this->table)->get()->getResultArray();
    }

    public function crearUsuario($data)
    {
        return $this->db->table($this->table)->insert($data);
    }

    public function actualizarUsuario($data, $where)
    {
        return $this->db->table($this->table)->where($where)->update($data);
    }

    public function eliminarUsuario($where)
    {
        return $this->db->table($this->table)->where($where)->delete();
    }

    public function obtenerRolesYModulos($id_usuario)
    {
        // Consulta SQL para obtener roles y módulos asociados al usuario
        $builder = $this->db->table('usuarios u');
        $builder->select('r.nombre_rol, m.nombre_modulo');
        $builder->join('usuario_rol ur', 'ur.id_usuario = u.id_usuario');
        $builder->join('roles r', 'r.id_rol = ur.id_rol');
        $builder->join('rol_modulo rm', 'rm.id_rol = r.id_rol');
        $builder->join('modulos m', 'm.id_modulo = rm.id_modulo');
        $builder->where('u.id_usuario', $id_usuario);

        // Ejecutar la consulta y devolver los resultados
        return $builder->get()->getResultArray();
    }

}
?>

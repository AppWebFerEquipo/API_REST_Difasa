<?php

namespace App\Models;

use CodeIgniter\Model;


class MModulos extends Model
{
    protected $table;
    protected $db;

    public function __construct()
    {
        parent::__construct();
        $this->table = 'modulos';
        $this->db = \Config\Database::connect();

    }

    public function obtenerModulos($where = null)
    {
        if ($where) {
            return $this->db->table($this->table)->where($where)->get()->getResultArray();
        }
        return $this->db->table($this->table)->get()->getResultArray();
    }

    public function crearModulo($data)
    {
        return $this->db->table($this->table)->insert($data);
    }

    public function actualizarModulo($data, $where)
    {
        return $this->db->table($this->table)->where($where)->update($data);
    }

    public function eliminarModulo($where)
    {
        return $this->db->table($this->table)->where($where)->delete();
    }
}
?>

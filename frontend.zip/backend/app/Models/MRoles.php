<?php

namespace App\Models;

use CodeIgniter\Model;


class MRoles extends Model
{
    protected $table;
    protected $db;

    public function __construct()
    {
        parent::__construct();
        $this->table = 'roles';
        $this->db = \Config\Database::connect();

    }

    public function obtenerRoles($where = null)
    {
        if ($where) {
            return $this->db->table($this->table)->where($where)->get()->getResultArray();
        }
        return $this->db->table($this->table)->get()->getResultArray();
    }

    public function crearRol($data)
    {
        return $this->db->table($this->table)->insert($data);
    }

    public function actualizarRol($data, $where)
    {
        return $this->db->table($this->table)->where($where)->update($data);
    }

    public function eliminarRol($where)
    {
        return $this->db->table($this->table)->where($where)->delete();
    }
}
?>

<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');

$routes->post('/login', 'Auth\CLogin::index');

$routes->get('/usuarios', 'Usuarios\CUsuarios::index');
$routes->post('/usuarios/crear', 'Usuarios\CUsuarios::create');
$routes->put('/usuarios/actualizar', 'Usuarios\CUsuarios::update');
$routes->delete('/usuarios/eliminar', 'Usuarios\CUsuarios::delete');

$routes->get('/roles', 'Roles\CRoles::index');
$routes->post('/roles/crear', 'Roles\CRoles::create');
$routes->put('/roles/actualizar', 'Roles\CRoles::update');
$routes->delete('/roles/eliminar', 'Roles\CRoles::delete');

$routes->get('/modulos', 'Modulos\CModulos::index');
$routes->post('/modulos/crear', 'Modulos\CModulos::create');
$routes->put('/modulos/actualizar', 'Modulos\CModulos::update');
$routes->delete('/modulos/eliminar', 'Modulos\CModulos::delete');

